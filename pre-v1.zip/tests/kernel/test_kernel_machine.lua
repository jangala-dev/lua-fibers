package.path = table.concat({
  './src/?.lua',
  './src/?/init.lua',
  './src/?/?.lua',
  './reference/?.lua',
  './reference/?/init.lua',
  './reference/?/?.lua',
  './?.lua',
  './?/init.lua',
  './?/?.lua',
  package.path,
}, ';')
local Runtime = require('fibers.runtime')
local IR = require('fibers.internal.kernel.ir')
local Store = require('fibers.internal.kernel.ledger')
local Op = require('fibers.op')
local Facility = require('fibers.resource.authoring')
local Scalar = require('fibers.resource.scalar')

local function eq(a, b, m)
  if a ~= b then
    error((m or 'assert') .. ': expected ' .. tostring(b) .. ', got ' .. tostring(a), 2)
  end
end
local Kind = { name = 'lazy-witness-test' }
local loc = Store.new_location({ name = 'lazy-witness', algebra = 'machine', domain = 'plain', value = 0 })
local opened, next_calls = 0, 0
local p = Facility.witness({
  accepts_supply = true,
  supplies = 'any',
  location = loc,
  cursor = function(state)
    opened = opened + 1
    local i = 0
    return {
      next = function()
        i = i + 1
        next_calls = next_calls + 1
        if i == 1 then
          return { value = 1, result = Op._pack('first'), writes = true }
        end
        if i == 2 then
          return { value = 2, result = Op._pack('second'), writes = true }
        end
        return nil
      end,
    }
  end,
})
local resource = { _fibers_kind = Kind }
local rt = Runtime.new()
local got
rt:spawn_raw(function()
  got = rt:perform(Facility.op(resource, Kind, p))
end)
eq(rt:run().tag, 'found')
eq(got, 'first')
-- One readiness probe and one execution cursor are permitted; neither may
-- enumerate the unused second candidate.
if next_calls > 2 then
  error('witness cursor was eagerly exhausted: ' .. next_calls, 2)
end

-- The ledger machine and reference machine must agree on a backtracking world.
local function scenario(machine)
  local r = Runtime.new({ machine = machine })
  local s = Scalar.new(0)
  local out
  r:spawn_raw(function()
    out = r:perform(Op.tensor({
      Op.choice(s:write_op(1), s:write_op(2)),
      s:write_op(2),
    }))
  end)
  local st = r:run()
  return st.tag, s.value, out and out[1] and out[1][1]
end
local a, b, c = scenario('ledger')
local x, y, z = scenario('reference')
eq(a, x)
eq(b, y)
eq(c, z)
print('tests/test_kernel_machine.lua: ok')
