# Facility authoring

Most extensions should be ordinary Lua modules which compose supported options and resources. They should not depend on `fibers.internal`.

## Shape of a facility

A facility normally:

1. owns one or more supported resources;
2. exposes methods ending in `_op`;
3. returns inert options without calling `perform` internally;
4. uses `all`, `tensor`, `choice`, sequencing and mapping to state its laws;
5. leaves fibre and lifetime structure to callers unless ownership is intrinsic to the facility.

```lua
local Op = require('fibers.op')
local Scalar = require('fibers.resource.scalar')

local Latch = {}
Latch.__index = Latch

function Latch.new(count)
  return setmetatable({ state = Scalar.new(count or 0, 'latch') }, Latch)
end

function Latch:wait_op()
  local function loop()
    return self.state:snapshot_op():and_then(function(snapshot)
      if snapshot.value == 0 then
        return Op.always(true)
      end
      return self.state:changed_op(snapshot.version):and_then(loop)
    end)
  end
  return loop()
end
```

## Naming

Use `_op` for methods which construct composable options. Reserve plain methods for immediate inspection or local construction which cannot suspend or commit transactional state.

## Normative callback discipline

Facilities must place each callback in one of three phases.

| Phase | Facility callbacks | Requirements |
|---|---|---|
| Speculative search | guards, `map`, `and_then`, transition rules, effect `key` and `merge` | Deterministic, non-yielding and replayable. No external mutation, performing, spawning or irreversible work. |
| Committed-world effect protocol | effect `prepare` and `discharge` | `prepare` is pure and may be called repeatedly or discarded. It returns either a structured refusal or a prepared record with `discharge`. `discharge` runs once after state installation. |
| Participant continuation | `wrap` | Runs after commit in the resumed fibre. It may perform, spawn and interact with the outside world. |

`prepare` must not reserve host capacity or acquire an external resource. It may inspect only the effect payload, immutable runtime configuration and managed facts already represented by the candidate. A refusal based on untracked volatile host state is invalid because it could admit an `or_else` fallback without a revalidatable proof. Model such capacity or readiness as a managed resource, then put the irreversible host action in `discharge`.

Effect identity is `(EffectKind, key)` using raw Lua identity. Do not stringify keys in an effect kind. Values of different types remain distinct; table and userdata keys use object identity; `nil` is supported; NaN is not. `merge` is called only for effects of the same kind with the same raw key.

Use a typed effect when the work belongs to the committed world. Use `wrap` when it belongs to one resumed participant.

## Composition before new mechanisms

Prefer:

- Channel for application communication;
- Scalar for state machines;
- Pulse for coalescing notification;
- Scope and Task for owned work;
- the resource toolkit for allocation and compatibility laws.

A new public facility should have a distinct law, compose with the option algebra, and remove recurring application complexity. A convenience which merely saves a few lines is usually better as a recipe.

## Worked recipes

The repository contains complete examples under `examples/recipes/`:

- token-bucket rate limiter;
- countdown latch;
- priority queue;
- resource pool.

These recipes are tested but are not part of the installed version 1 surface.

## Closed kernel protocol

The kernel IR and store are implementation details under `fibers.internal.kernel`. New trusted resource programmes require repository-level review and are covered by `../contributing/trusted-resource-programmes.md`.
