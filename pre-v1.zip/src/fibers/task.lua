-- Task: public owned computation.
--
-- A Task is not a second scheduler primitive. It is the standard owned running
-- work abstraction built from the supported resource and lifetime layers. Region
-- admits ownership, Scalar holds completion and cancellation facts, and Effect.spawn starts the fibre after
-- commit.

local Op = require('fibers.op')
local Runtime = require('fibers.runtime')
local perform = require('fibers.perform')
local Scalar = require('fibers.resource.scalar')
local Effect = require('fibers.effect')
local Region = require('fibers.region')
local Owned = require('fibers.region').Owned
local Settlement = require('fibers.region.settlement')
local Protected = require('fibers.internal.protected')

local unpack_ = table.unpack or unpack
local Exit = {}
Exit.__index = Exit

local unpack_ = table.unpack or unpack

local function exit_pack(...)
  return { n = select('#', ...), ... }
end

local function new_exit(tag, fields)
  fields = fields or {}
  fields.tag = tag
  fields._fibers_exit = true
  return setmetatable(fields, Exit)
end

function Exit.returned(...)
  return new_exit('returned', { values = exit_pack(...) })
end

function Exit.failed(err)
  return new_exit('failed', { error = err })
end

function Exit.cancelled(reason, token)
  return new_exit('cancelled', { reason = reason, token = token })
end

function Exit.is(x)
  return type(x) == 'table' and x._fibers_exit == true
end

function Exit.status(x)
  return Exit.is(x) and x.tag or nil
end

function Exit.unwrap(x)
  if not Exit.is(x) then
    error('Exit.unwrap expects an Exit value', 2)
  end
  if x.tag == 'returned' then
    local vals = x.values or { n = 0 }
    return unpack_(vals, 1, vals.n or #vals)
  elseif x.tag == 'cancelled' then
    error(Runtime.cancelled(x.reason, x.token), 0)
  elseif x.tag == 'failed' then
    error(x.error, 0)
  end
  error('unknown task exit tag ' .. tostring(x.tag), 2)
end

function Exit:tostring()
  if self.tag == 'returned' then
    return 'Exit.returned'
  end
  if self.tag == 'cancelled' then
    return 'Exit.cancelled: ' .. tostring(self.reason)
  end
  if self.tag == 'failed' then
    return 'Exit.failed: ' .. tostring(self.error)
  end
  return 'Exit.' .. tostring(self.tag)
end

Exit.__tostring = Exit.tostring

local function pack(...)
  return { _fibers_pack = true, n = select('#', ...), ... }
end

local Task = {}
Task.__index = Task

local RequestCancel = Scalar.transition({
  name = 'task.request_cancel',
  mode = 'update',
  accepts_supply = true,
  supplies = 'any',
  step = function(state, payload)
    if type(state) == 'table' and (state.cancelled or state.requested) then
      return Scalar.Ready.same(false, state.reason)
    end
    local next_state = { requested = true, cancelled = true, reason = payload.reason }
    return Scalar.Ready.write(next_state, true, payload.reason)
  end,
})

local next_id = 0

local function is_pending(v)
  return type(v) == 'table' and v.status == 'pending'
end

local function wait_for_scalar(scalar, pred)
  return Scalar.value_op(scalar, pred)
end

function Task.new(fn, name, scope)
  if type(fn) ~= 'function' then
    error('Task.new expects a function', 2)
  end
  next_id = next_id + 1
  local id = 'task-' .. tostring(next_id)
  return setmetatable({
    fn = fn,
    name = name or id,
    completion = Scalar.new({ status = 'pending' }, (name or id) .. '-completion'),
    cancellation = Scalar.new({ requested = false, cancelled = false }, (name or id) .. '-cancellation'),
    interrupt = Runtime._new_interrupt((name or id) .. '-interrupt'),
    scope = scope,
    owner = nil,
    owner_version = 0,
    _fibers_obligation_kind = 'task',
    _fibers_id = id,
    _fibers_kind = Region.OwnershipKind,
    _fibers_settle = Settlement.task_interrupt(),
    _fibers_settle_name = 'task_interrupt',
  }, Task)
end

function Task:_spawn_body(fn)
  local task = self
  return function()
    local rt = Runtime.current()
    if not rt then
      error('task started without a current runtime', 2)
    end
    local results = pack(Protected.pcall(fn, task))
    fn = nil
    local ok = results[1]
    local exit
    if ok then
      exit = Exit.returned(unpack_(results, 2, results.n))
    else
      local err = results[2]
      if Runtime.is_cancelled and Runtime.is_cancelled(err) then
        exit = Exit.cancelled(err.reason, err.token)
      else
        exit = Exit.failed(err)
      end
    end
    local completion_write = task.completion:write_op(exit)
    rt:perform(
      task.completion:read_op():and_then(function(v)
        if not is_pending(v) then
          return Op.always(false)
        end
        return completion_write:and_then(function()
          return Op.emit(Effect.scope({
            type = 'task_exit',
            item = task,
            task = task,
            exit = exit,
          })):map(function()
            return true
          end)
        end, false)
      end, Op.dependencies(completion_write)),
      { masked = true }
    )
  end
end

function Task:_start_internal(rt, scope)
  if not rt or type(rt._spawn_committed) ~= 'function' then
    error('Task:_start_internal requires a Runtime', 2)
  end
  local body = self:_spawn_body(self.fn)
  self.fn = nil
  self.scope = nil
  return rt:_spawn_committed(body, self.name, scope)
end

function Task:_spawn_effect()
  -- The start function and scope are consumed by the committed spawn effect.
  -- The Task handle remains a handle to completion/cancellation state; it is
  -- not a long-lived archive of the start closure.
  return Effect.spawn(self:_spawn_body(self.fn), self.name, self._fibers_id, self.scope, self)
end

function Task:owned(settle, opts)
  opts = opts or {}
  opts.role = opts.role or 'task'
  opts.settle_name = opts.settle_name or self._fibers_settle_name or 'task_interrupt'
  return Owned.item(self, settle or self._fibers_settle or Settlement.task_interrupt(), opts)
end

function Task:spawn_effect_op()
  return Op.emit(self:_spawn_effect()):map(function()
    return self
  end)
end

function Task:start_op(region, settle, opts)
  if not region or type(region.admit_op) ~= 'function' then
    error('Task:start_op expects a Region', 2)
  end
  local task = self
  return region:admit_op(task:owned(settle, opts)):and_then(function()
    return task:spawn_effect_op()
  end, false)
end

function Task.spawn_op(region, fn, name)
  local opts = type(name) == 'table' and name or nil
  if opts then
    name = opts.name
  end
  if not region or type(region.admit_op) ~= 'function' then
    error('Task.spawn_op expects a Region', 2)
  end
  local task = Task.new(fn, name)
  if opts and type(opts.scope) == 'function' then
    task.scope = opts.scope(task)
  elseif opts then
    task.scope = opts.scope
  end
  return task:start_op(region, opts and opts.settle or nil, opts)
end

function Task:exit_op()
  return wait_for_scalar(self.completion, Exit.is)
end

function Task:await_op()
  return self:exit_op():wrap(function(exit)
    return Exit.unwrap(exit)
  end)
end

function Task:request_cancel_op(reason)
  return self.cancellation
    :transition_op(RequestCancel, { reason = reason })
    :and_then(function(first, recorded_reason)
      if not first then
        return Op.always(false, recorded_reason)
      end
      return Op.emit(Effect.interrupt(self.interrupt, recorded_reason)):map(function()
        return true, recorded_reason
      end)
    end, false)
end

function Task:cancel_requested_op()
  return wait_for_scalar(self.cancellation, function(v)
    return type(v) == 'table' and (v.cancelled or v.requested)
  end):map(function(v)
    return true, v.reason
  end)
end

function Task:state_op()
  local cancellation_read = self.cancellation:read_op()
  return self.completion:read_op():and_then(function(completion)
    return cancellation_read:map(function(cancel)
      return {
        exited = Exit.is(completion),
        exit = completion,
        cancel_requested = type(cancel) == 'table' and (cancel.cancelled or cancel.requested) or false,
        cancel_reason = type(cancel) == 'table' and cancel.reason or nil,
        task = self,
      }
    end)
  end, Op.dependencies(cancellation_read))
end

function Task:await()
  return perform(self:await_op())
end

function Task:request_cancel(reason)
  return perform(self:request_cancel_op(reason))
end

Task.Exit = Exit
return Task
